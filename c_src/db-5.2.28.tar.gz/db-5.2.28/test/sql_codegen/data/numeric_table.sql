
CREATE DATABASE numismatics;

CREATE TABLE table1 (att_numeric NUMERIC PRIMARY KEY);